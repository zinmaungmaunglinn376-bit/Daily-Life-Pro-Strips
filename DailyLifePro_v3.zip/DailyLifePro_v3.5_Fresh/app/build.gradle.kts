plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.dailylife.pro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dailylife.pro"
        minSdk = 23
        targetSdk = 35
        versionCode = 10
        versionName = "3.5"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
